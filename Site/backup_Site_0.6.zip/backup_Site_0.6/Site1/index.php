﻿<?php

	
	include("header.inc");
	
	include("body.inc");

    include("footer.inc");

?>